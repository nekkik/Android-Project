package com.example.maverickandskills;

public class Profiles {

    private String name;
    private String createProMajor;
    private String createProDOB;
    private String phone;
    private String email;
    private String skills;
    private String createProBio;
    private String uid;

    public Profiles() {
    }

    public String getname() {
        return name;
    }

    public void setname(String name) {
        this.name = name;
    }

    public String getCreateProMajor() {
        return createProMajor;
    }

    public void setCreateProMajor(String createProMajor) {
        this.createProMajor = createProMajor;
    }

    public String getCreateProDOB() {
        return createProDOB;
    }

    public void setCreateProDOB(String createProDOB) {
        this.createProDOB = createProDOB;
    }

    public String getphone() {
        return phone;
    }

    public void setphone(String phone) {
        this.phone = phone;
    }

    public String getemail() {
        return email;
    }

    public void setemail(String email) {
        this.email = email;
    }

    public String getskills() {
        return skills;
    }

    public void setskills(String skills) {
        this.skills = skills;
    }

    public String getCreateProBio() {
        return createProBio;
    }

    public void setCreateProBio(String createProBio) {
        this.createProBio = createProBio;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }
}
